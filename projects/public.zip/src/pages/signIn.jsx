import PageHeader from "../components/common/pageHeader";

function SignIn() {
  return (
    <div className="container">
      <PageHeader title="Sign In" description="Sign in with your account" />
    </div>
  );
}

export default SignIn;

