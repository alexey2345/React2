import NavBar from "./navbar.jsx";

function Header() {
  return (
    <header>
      <NavBar />
    </header>
  );
}
export default Header;
