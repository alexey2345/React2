function Logo() {
  return (
    <span>
      Real<i className="bi bi-geo-fill"></i>App
    </span>
  );
}

export default Logo;
